/**
 * ASL Live — On-Device Real-Time Sign Language Translator
 * ---------------------------------------------------------
 * 100% client-side. The only network requests this file makes are the
 * one-time CDN downloads of the MediaPipe Tasks-Vision WASM runtime and the
 * hand-landmark model weights. After that initial load, everything —
 * camera capture, landmark inference, geometry math, sign classification,
 * temporal smoothing, and speech synthesis — runs locally inside this tab.
 * No frame, coordinate, or prediction is ever sent anywhere.
 */

import {
  HandLandmarker,
  FilesetResolver
} from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";

/* ------------------------------------------------------------------ */
/*  DOM references                                                     */
/* ------------------------------------------------------------------ */

const video = document.getElementById("webcam");
const canvasElement = document.getElementById("output_canvas");
const canvasCtx = canvasElement.getContext("2d");
const subtitleEl = document.getElementById("subtitle");
const startBtn = document.getElementById("startBtn");
const speechToggle = document.getElementById("speechToggle");
const statusEl = document.getElementById("status");
const currentSignEl = document.getElementById("currentSign");
const idleOverlay = document.getElementById("idleOverlay");

/* ------------------------------------------------------------------ */
/*  State                                                               */
/* ------------------------------------------------------------------ */

let handLandmarker = undefined;
let webcamRunning = false;
let lastVideoTime = -1;

let speechEnabled = true;
let lastSpokenLabel = "";
const speechSynth = window.speechSynthesis;

/* Temporal consensus smoothing buffer.
 * We keep the last N raw predictions and only "commit" a label to the
 * subtitle / speech output once it dominates the buffer. This kills
 * frame-to-frame flicker caused by momentary tracking jitter. */
const SMOOTHING_WINDOW = 10;
const STABILITY_THRESHOLD = 7;
let predictionQueue = [];
let stableLabel = "";

/* Standard 21-point hand skeleton connections (MediaPipe Hand Landmark topology) */
const HAND_CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17]
];

/* ------------------------------------------------------------------ */
/*  MediaPipe Tasks-Vision initialization                               */
/* ------------------------------------------------------------------ */

async function createHandLandmarker() {
  statusEl.textContent = "Loading AI model (on-device, ~10 MB)...";

  const vision = await FilesetResolver.forVisionTasks(
    "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
  );

  handLandmarker = await HandLandmarker.createFromOptions(vision, {
    baseOptions: {
      modelAssetPath:
        "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task",
      delegate: "GPU"
    },
    runningMode: "VIDEO",
    numHands: 1,
    minHandDetectionConfidence: 0.6,
    minHandPresenceConfidence: 0.6,
    minTrackingConfidence: 0.6
  });

  statusEl.textContent = "Model ready. Click \"Start Camera\" to begin.";
  startBtn.disabled = false;
}

createHandLandmarker().catch((err) => {
  console.error(err);
  statusEl.textContent =
    "Could not load the AI model. Check your internet connection for this one-time download, then reload.";
});

/* ------------------------------------------------------------------ */
/*  Webcam control                                                      */
/* ------------------------------------------------------------------ */

startBtn.addEventListener("click", () => {
  if (!webcamRunning) {
    enableCam();
  } else {
    disableCam();
  }
});

async function enableCam() {
  if (!handLandmarker) {
    statusEl.textContent = "AI model still loading, please wait...";
    return;
  }

  const constraints = {
    video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: "user" }
  };

  try {
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    video.srcObject = stream;
    video.addEventListener("loadeddata", predictWebcam);
    webcamRunning = true;
    startBtn.textContent = "Stop Camera";
    idleOverlay.classList.add("hidden");
  } catch (err) {
    console.error(err);
    statusEl.textContent =
      "Camera access was denied or is unavailable on this device.";
    idleOverlay.classList.remove("hidden");
  }
}

function disableCam() {
  const stream = video.srcObject;
  if (stream) {
    stream.getTracks().forEach((track) => track.stop());
  }
  video.srcObject = null;
  webcamRunning = false;
  startBtn.textContent = "Start Camera";
  statusEl.textContent = 'Camera stopped. Click "Start Camera" to resume.';
  idleOverlay.classList.remove("hidden");

  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  subtitleEl.textContent = "";
  currentSignEl.textContent = "\u2014";
  predictionQueue = [];
  stableLabel = "";
  lastSpokenLabel = "";
  speechSynth.cancel();
}

speechToggle.addEventListener("change", () => {
  speechEnabled = speechToggle.checked;
  if (!speechEnabled) speechSynth.cancel();
});

/* ------------------------------------------------------------------ */
/*  Main per-frame prediction loop                                      */
/* ------------------------------------------------------------------ */

async function predictWebcam() {
  if (!webcamRunning) return;

  if (canvasElement.width !== video.videoWidth) {
    canvasElement.width = video.videoWidth;
    canvasElement.height = video.videoHeight;
  }

  const startTimeMs = performance.now();
  if (lastVideoTime !== video.currentTime) {
    lastVideoTime = video.currentTime;
    const results = handLandmarker.detectForVideo(video, startTimeMs);
    processResults(results);
  }

  window.requestAnimationFrame(predictWebcam);
}

function processResults(results) {
  canvasCtx.save();
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

  if (results.landmarks && results.landmarks.length > 0) {
    const landmarks = results.landmarks[0];
    drawLandmarks(landmarks);

    const normalized = normalizeLandmarks(landmarks);
    const rawLabel = predictSign(normalized, landmarks);

    pushToSmoothingQueue(rawLabel);
    updateStableLabel();
  } else {
    pushToSmoothingQueue("");
    updateStableLabel();
  }

  canvasCtx.restore();
}

/* ------------------------------------------------------------------ */
/*  Skeleton rendering                                                  */
/* ------------------------------------------------------------------ */

function drawLandmarks(landmarks) {
  const w = canvasElement.width;
  const h = canvasElement.height;

  canvasCtx.lineWidth = 3;
  canvasCtx.strokeStyle = "rgba(0, 229, 255, 0.85)";
  HAND_CONNECTIONS.forEach(([startIdx, endIdx]) => {
    const start = landmarks[startIdx];
    const end = landmarks[endIdx];
    canvasCtx.beginPath();
    canvasCtx.moveTo(start.x * w, start.y * h);
    canvasCtx.lineTo(end.x * w, end.y * h);
    canvasCtx.stroke();
  });

  canvasCtx.fillStyle = "#ff2d95";
  landmarks.forEach((lm) => {
    canvasCtx.beginPath();
    canvasCtx.arc(lm.x * w, lm.y * h, 4, 0, 2 * Math.PI);
    canvasCtx.fill();
  });

  // Highlight the wrist (landmark 0) since it is the origin of our
  // normalization frame — useful for debugging/demoing the pipeline.
  const wrist = landmarks[0];
  canvasCtx.fillStyle = "#00e5ff";
  canvasCtx.beginPath();
  canvasCtx.arc(wrist.x * w, wrist.y * h, 7, 0, 2 * Math.PI);
  canvasCtx.fill();
}

/* ------------------------------------------------------------------ */
/*  Coordinate normalization                                            */
/*  Every landmark is re-expressed relative to the wrist (landmark 0)  */
/*  and then scaled by the wrist-to-middle-MCP distance. This makes    */
/*  the downstream geometry invariant to hand position on screen and   */
/*  to how close/far the hand is from the camera.                      */
/* ------------------------------------------------------------------ */

function normalizeLandmarks(landmarks) {
  const wrist = landmarks[0];

  const translated = landmarks.map((lm) => ({
    x: lm.x - wrist.x,
    y: lm.y - wrist.y,
    z: lm.z - wrist.z
  }));

  const middleMcp = translated[9];
  const scale =
    Math.hypot(middleMcp.x, middleMcp.y, middleMcp.z) || 1;

  return translated.map((lm) => ({
    x: lm.x / scale,
    y: lm.y / scale,
    z: lm.z / scale
  }));
}

/* ------------------------------------------------------------------ */
/*  Geometry helpers                                                    */
/* ------------------------------------------------------------------ */

function dist3(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
}

function vec(a, b) {
  return { x: b.x - a.x, y: b.y - a.y, z: b.z - a.z };
}

function angleBetween(v1, v2) {
  const dot = v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
  const mag1 = Math.hypot(v1.x, v1.y, v1.z);
  const mag2 = Math.hypot(v2.x, v2.y, v2.z);
  if (mag1 === 0 || mag2 === 0) return 0;
  const cos = Math.min(1, Math.max(-1, dot / (mag1 * mag2)));
  return (Math.acos(cos) * 180) / Math.PI;
}

/**
 * Classifies a single finger's curl using the summed bend angle across
 * its two inter-joint vectors. A perfectly straight finger has a total
 * bend near 0°; a fully curled finger folds back sharply (large bend).
 * Using angles (rather than raw y-coordinates) keeps this robust to
 * hand rotation and tilt in front of the camera.
 */
function fingerCurlState(j0, j1, j2, j3) {
  const v1 = vec(j0, j1);
  const v2 = vec(j1, j2);
  const v3 = vec(j2, j3);
  const bend = angleBetween(v1, v2) + angleBetween(v2, v3);

  if (bend < 35) return "extended";
  if (bend > 95) return "curled";
  return "partial";
}

/**
 * Average angular spacing between adjacent fingertip vectors as seen
 * from the wrist. Large values mean the fingers are fanned/spread apart
 * (e.g. an open "Hello" wave); small values mean fingers are held
 * together (e.g. the flat "B" / "Thank You" handshapes).
 */
function fingerSpread(n) {
  const origin = { x: 0, y: 0, z: 0 };
  const idx = vec(origin, n[8]);
  const mid = vec(origin, n[12]);
  const ring = vec(origin, n[16]);
  const pinky = vec(origin, n[20]);

  const a1 = angleBetween(idx, mid);
  const a2 = angleBetween(mid, ring);
  const a3 = angleBetween(ring, pinky);

  return (a1 + a2 + a3) / 3;
}

/* ------------------------------------------------------------------ */
/*  Rule-based ASL classifier                                           */
/*                                                                       */
/*  predictSign() receives:                                             */
/*    n           -> 21 landmarks, wrist-relative & scale-normalized     */
/*    rawLandmarks-> original MediaPipe output (0-1 screen space),      */
/*                   used only for the coarse "hand height on screen"   */
/*                   check that disambiguates "B" from "Thank You".     */
/*                                                                       */
/*  The function evaluates finger curl states, key fingertip            */
/*  distances, and fan-out spread, then walks an ordered decision       */
/*  tree from most to least geometrically specific.                     */
/* ------------------------------------------------------------------ */

function predictSign(n, rawLandmarks) {
  const thumb = fingerCurlState(n[1], n[2], n[3], n[4]);
  const index = fingerCurlState(n[5], n[6], n[7], n[8]);
  const middle = fingerCurlState(n[9], n[10], n[11], n[12]);
  const ring = fingerCurlState(n[13], n[14], n[15], n[16]);
  const pinky = fingerCurlState(n[17], n[18], n[19], n[20]);

  const thumbToIndexTip = dist3(n[4], n[8]);
  const thumbToMiddleTip = dist3(n[4], n[12]);
  const thumbToIndexMcp = dist3(n[4], n[5]);

  const spread = fingerSpread(n);

  const extendedCount = [index, middle, ring, pinky].filter(
    (s) => s === "extended"
  ).length;
  const curledCount = [index, middle, ring, pinky].filter(
    (s) => s === "curled"
  ).length;
  const partialCount = [index, middle, ring, pinky].filter(
    (s) => s === "partial"
  ).length;

  // --- O: fingertips curl in to meet the thumb, forming a closed loop ---
  if (
    curledCount + partialCount === 4 &&
    thumb !== "curled" &&
    thumbToIndexTip < 0.55 &&
    thumbToMiddleTip < 0.75
  ) {
    return "O";
  }

  // --- A: closed fist, thumb resting against the side (not touching tips) ---
  if (
    curledCount >= 3 &&
    partialCount <= 1 &&
    thumb !== "curled" &&
    thumbToIndexTip >= 0.55
  ) {
    return "A";
  }

  // --- D: only the index finger stands up; thumb meets the middle finger ---
  if (
    index === "extended" &&
    middle !== "extended" &&
    ring !== "extended" &&
    pinky !== "extended" &&
    thumbToMiddleTip < 0.6
  ) {
    return "D";
  }

  // --- L: index finger and thumb form a right angle ---
  if (
    index === "extended" &&
    thumb === "extended" &&
    middle !== "extended" &&
    ring !== "extended" &&
    pinky !== "extended"
  ) {
    const indexVec = vec(n[5], n[8]);
    const thumbVec = vec(n[1], n[4]);
    const thumbIndexAngle = angleBetween(indexVec, thumbVec);
    if (thumbIndexAngle > 50) return "L";
  }

  // --- I: only the pinky stands up ---
  if (
    pinky === "extended" &&
    index !== "extended" &&
    middle !== "extended" &&
    ring !== "extended"
  ) {
    return "I";
  }

  // --- Y: thumb and pinky extended outward, middle three fingers folded ---
  if (
    thumb === "extended" &&
    pinky === "extended" &&
    index !== "extended" &&
    middle !== "extended" &&
    ring !== "extended"
  ) {
    return "Y";
  }

  // --- C: every finger (including thumb) is only partially curled, ---
  // --- tracing an open, curved "C" silhouette rather than a fist.  ---
  if (
    partialCount >= 3 &&
    curledCount === 0 &&
    thumb === "partial" &&
    thumbToIndexTip > 0.5 &&
    thumbToIndexTip < 1.4
  ) {
    return "C";
  }

  // --- Flat, four-finger handshapes: B / Thank You / Hello ---
  if (extendedCount === 4) {
    if (spread > 14) {
      // Fingers fanned wide apart with an open thumb -> friendly open-palm wave
      return "Hello";
    }

    // Fingers held together. Distinguish the resting "B" handshape from
    // "Thank You" using the wrist's vertical screen position: the ASL
    // "Thank You" sign is performed with a flat hand held up near the
    // chin/face, i.e. higher (smaller y) in the camera frame than the
    // neutral "B" handshape shown lower, around chest height.
    const wristScreenY = rawLandmarks[0].y;
    if (wristScreenY < 0.45 && thumbToIndexMcp < 0.6) {
      return "Thank You";
    }
    return "B";
  }

  return "";
}

/* ------------------------------------------------------------------ */
/*  Temporal consensus smoothing                                        */
/* ------------------------------------------------------------------ */

function pushToSmoothingQueue(label) {
  predictionQueue.push(label);
  if (predictionQueue.length > SMOOTHING_WINDOW) {
    predictionQueue.shift();
  }
}

function mostFrequent(arr) {
  const counts = {};
  let bestLabel = "";
  let bestCount = 0;

  for (const item of arr) {
    if (!item) continue;
    counts[item] = (counts[item] || 0) + 1;
    if (counts[item] > bestCount) {
      bestCount = counts[item];
      bestLabel = item;
    }
  }

  return { label: bestLabel, count: bestCount };
}

function updateStableLabel() {
  const { label, count } = mostFrequent(predictionQueue);

  if (label !== "" && count >= STABILITY_THRESHOLD) {
    if (label !== stableLabel) {
      stableLabel = label;
      displaySubtitle(stableLabel);
      speakLabel(stableLabel);
    }
    return;
  }

  // If the buffer is full but no sign dominates it (hand removed, or a
  // transition between signs), clear the subtitle so nothing stale lingers.
  const emptyOrLowConfidence =
    predictionQueue.length === SMOOTHING_WINDOW && count < 3;

  if (emptyOrLowConfidence && stableLabel !== "") {
    stableLabel = "";
    displaySubtitle("");
  }
}

function displaySubtitle(label) {
  subtitleEl.textContent = label;
  currentSignEl.textContent = label || "\u2014";
}

/* ------------------------------------------------------------------ */
/*  Offline text-to-speech via the native Web Speech API                */
/* ------------------------------------------------------------------ */

function speakLabel(label) {
  if (!speechEnabled || !label) return;
  if (label === lastSpokenLabel) return;
  if (!("speechSynthesis" in window)) return;

  lastSpokenLabel = label;
  speechSynth.cancel();

  const utterance = new SpeechSynthesisUtterance(label);
  utterance.rate = 1;
  utterance.pitch = 1;
  utterance.volume = 1;
  speechSynth.speak(utterance);
}
