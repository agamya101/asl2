# 🤟 ASL Live — On-Device Real-Time Sign Language Translator

**Built for OSDHack 2026** — a fully local, offline-first American Sign
Language translator that runs entirely inside your browser tab. No cloud AI
APIs, no servers, no accounts, no data collection. Ever.

> Point your webcam at your hand, form an ASL letter or phrase, and watch it
> appear as a live subtitle — and hear it spoken aloud — powered entirely by
> on-device WebAssembly inference and rule-based geometry, not a remote model.

---

## ✨ Why this qualifies as "On-Device AI"

| Pipeline stage | Where it runs | Network calls |
|---|---|---|
| Camera capture | Browser `getUserMedia` | None |
| Hand landmark detection | Google MediaPipe Tasks-Vision, compiled to **WebAssembly**, executed by your GPU/CPU **in-tab** | None (after the one-time model download) |
| Coordinate normalization | Pure JavaScript math | None |
| Sign classification | A hand-authored geometric rule engine (`predictSign()`) — **not** a cloud-hosted LLM or classifier | None |
| Temporal smoothing | A local 10-frame consensus queue | None |
| Text-to-speech | Native browser `window.speechSynthesis` (OS-level TTS voices) | None |

The **only** network activity this app ever makes is downloading two static
assets once per session, both served from CDNs:

1. The MediaPipe Tasks-Vision WASM runtime (`.wasm` binary)
2. The pre-trained hand-landmark detection weights (`hand_landmarker.task`)

Both are cached by the browser after first load. From that point forward,
**every single inference, every frame, every prediction happens locally** —
you can disconnect from the internet entirely and the app keeps working.

---

## 🧠 Architecture

```
┌─────────────┐     ┌──────────────────────┐     ┌────────────────────────┐
│   Webcam    │────▶│  MediaPipe Hand      │────▶│  21 hand landmarks     │
│  (getUserMedia)    │  Landmarker (WASM)   │     │  (x, y, z per joint)   │
└─────────────┘     └──────────────────────┘     └───────────┬────────────┘
                                                               │
                                                               ▼
                                          ┌─────────────────────────────────┐
                                          │ normalizeLandmarks()             │
                                          │ • translate: origin = wrist (0)  │
                                          │ • scale: ÷ wrist→middle-MCP dist │
                                          │   (distance-invariant geometry)  │
                                          └───────────────┬─────────────────┘
                                                          │
                                                          ▼
                                          ┌─────────────────────────────────┐
                                          │ predictSign()                    │
                                          │ Rule-based decision tree using:  │
                                          │  • per-finger bend angles        │
                                          │  • fingertip-to-thumb distances  │
                                          │  • fingertip fan-out spread      │
                                          │ → raw label per frame            │
                                          └───────────────┬─────────────────┘
                                                          │
                                                          ▼
                                          ┌─────────────────────────────────┐
                                          │ Temporal Consensus Queue          │
                                          │ Last 10 raw predictions           │
                                          │ Commit label only if ≥7/10 agree │
                                          │ → eliminates subtitle flicker    │
                                          └───────────────┬─────────────────┘
                                                          │
                                       ┌──────────────────┴──────────────────┐
                                       ▼                                     ▼
                              ┌─────────────────┐                 ┌───────────────────┐
                              │ Subtitle overlay │                 │ window.speechSynth │
                              │ (movie-caption   │                 │  .speak() — native │
                              │  style DOM text) │                 │  offline TTS       │
                              └─────────────────┘                 └───────────────────┘
```

### Why normalize relative to the wrist?

Landmark 0 (the wrist) is used as the coordinate origin for every other
joint. This makes the classifier **invariant to where your hand sits in the
camera frame** — sign in the corner or the center, it doesn't matter.
Dividing by the wrist→middle-finger-MCP distance additionally makes the
math **invariant to how close or far your hand is from the camera**, so the
same handshape is recognized whether your hand fills the frame or is
halfway across the room.

### Why a rule engine instead of a trained classifier?

A geometric decision tree over normalized joint angles and distances is:

- **Zero-download** beyond the hand-landmark model itself — no separate
  megabyte-heavy classifier weights to ship.
- **Fully transparent** — every classification traces back to an explicit,
  auditable geometric condition (e.g. "index finger extended, thumb touches
  the middle finger → D"), which is ideal for a hackathon demo and for
  debugging misclassifications live.
- **Instant** — no additional inference pass, just vector math on 21 points,
  so the whole pipeline comfortably runs above 30 FPS on modest laptops.

---

## 🔤 Recognized signs

| Sign | Handshape cue |
|---|---|
| **A** | Closed fist, thumb resting against the side |
| **B** | Flat hand, four fingers extended and together, thumb tucked across the palm |
| **C** | Hand curved into an open "C", fingers and thumb both partially bent |
| **D** | Index finger stands straight up, thumb touches the middle finger |
| **I** | Only the pinky stands up, rest of the hand closed |
| **L** | Thumb and index finger extended at a right angle |
| **O** | Fingertips curl in to touch the thumb, forming a circle |
| **Y** | Thumb and pinky extended outward ("hang loose"), middle fingers folded |
| **Hello** | Open palm, all five fingers extended and spread wide |
| **Thank You** | Flat hand, fingers together, held up near the chin/face |

---

## 📂 Project structure

```
.
├── index.html    # Markup: video/canvas stage, subtitle overlay, controls
├── styles.css    # Dark, modern "movie caption" UI theme
├── app.js        # MediaPipe init, normalization, rule engine, smoothing, TTS
├── LICENSE       # MIT
└── README.md     # This file
```

Everything is vanilla HTML/CSS/JS with **zero build tooling** — no npm
install, no bundler, no framework. Open `index.html` in any modern browser
(or deploy the folder as-is) and it works.

---

## 🚀 Running it locally

Because the app requests camera access, most browsers require a secure
context (`https://` or `localhost`) rather than a bare `file://` path. Any
lightweight static server works:

```bash
# Python 3
python3 -m http.server 8000

# or Node (no install needed beyond npx)
npx serve .
```

Then open `http://localhost:8000` and click **Start Camera**.

---

## 🌐 Deploying

### Vercel
1. Push this folder to a GitHub repository.
2. Import the repo in Vercel — no framework preset needed, no build command,
   output directory is the project root.
3. Deploy. Done.

### GitHub Pages
1. Push this folder to a GitHub repository.
2. Go to **Settings → Pages**, set the source to your default branch and
   root directory.
3. Your app will be live at `https://<username>.github.io/<repo>/`.

All paths in `index.html` and `app.js` are relative, so it works identically
whether served from a domain root or a GitHub Pages subpath.

---

## 🔒 Proving it's truly offline (do this at the hackathon demo!)

1. Load the page once **with internet access** so the browser can cache the
   two CDN assets (WASM runtime + model weights).
2. Click **Start Camera** and confirm hand tracking and sign detection work.
3. **Turn off your Wi-Fi / unplug ethernet / enable Airplane Mode.**
4. Keep signing — the subtitles keep appearing and speech keeps playing.
5. Open your browser's Network tab (DevTools) and refresh: you'll see no
   outgoing requests related to your video, your hand coordinates, or your
   predictions, because none are ever made in the first place — the model
   files simply load from the browser's HTTP cache, or you can pre-cache
   them once and reload with the network fully disabled to prove it further.

This is the core "zero-data-leak" guarantee: **your camera feed and every
derived coordinate never leave the JavaScript heap of your own browser tab.**

---

## 🛠️ Tech stack

- **Google MediaPipe Tasks-Vision** (WebAssembly) — on-device hand landmark
  detection, loaded from a public CDN, executed locally.
- **Vanilla JavaScript (ES Modules)** — normalization math, rule-based
  classifier, temporal smoothing, and UI logic.
- **Native `window.speechSynthesis`** — offline, OS-level text-to-speech.
- **Plain HTML5 + CSS3** — no frameworks, no bundlers, no build step.

---

## ⚠️ Notes & limitations

- Works best in good, even lighting with one hand clearly visible.
- Currently classifies a single hand (`numHands: 1`) for speed and clarity;
  the geometry pipeline generalizes to multiple hands if you raise this.
- The rule engine is intentionally interpretable rather than exhaustive — it
  targets 10 clear, distinguishable handshapes rather than the full ASL
  alphabet, in the spirit of a hackathon-scoped, auditable demo.
- `Hello` and `Thank You` are approximated as static handshapes (fan-spread
  vs. together, plus on-screen hand height) since true ASL production
  involves motion this single-frame classifier does not track.

---

## 📄 License

MIT — see [`LICENSE`](./LICENSE).
